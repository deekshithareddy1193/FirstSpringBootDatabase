package BackendDevelopers.FirstSpringBoot.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import BackendDevelopers.FirstSpringBoot.Model.Product;
import BackendDevelopers.FirstSpringBoot.dao.ProductsList;

/*Any class marked with @service controls concurrent or parallel access to the
 * DAO,layer,thereby preventing dataloss or data ambiguity or data corruption
 * 
 * @Servoice automatically creates a bean for ProductService
 */
@Service
public class ProductService {
	@Autowired
	ProductsList plist;
	//Mannually injecting productlist object into service
	public ArrayList<Product> getProductsList(){
		System.out.println("Getting productsList");
		//When you call FindAll() method in the repository,it executes a SQL SELECT * from 
		//products statements on the database
		return (ArrayList<Product>)plist.findAll();
	}
	public String addProduct(Product p) 
	{
		System.out.println("In service, adding product");
		Product t=plist.save(p);//Converts this to SQL insert save
		return "<b>Added or inserted the product</b>" +t;
	}
	public String deleteProduct(int productId) 
	{
		System.out.println("In service, Deleting product");
		//For ex: if productId is 3,
		//When deleteById() is called,it converts this into SQL DELETE from product where
		//productId=3
		plist.deleteById(productId);
		return "<b>Deleted product with ID</b>"+productId;
	}
	public String searchById(int productId) 
	{
		System.out.println("In service, Searching By ID");
		//If productId is 4,this is converted to SQL
		//SELECT * from Product where productId=4
		Optional<Product> opt=plist.findById(productId);
		return "Located productId "+opt.get().toString();
	}
	public String updateProduct(int productId,String newProductName) 
	{
		System.out.println("In service, Updating product");
		Product d=new Product(productId,newProductName);
		//When save() method is called if any product with given productId is existing
		//it updates product name with new productName otherwise it inserts a new record.
		return "Updated product with "+plist.save(d).toString();
	}


}
