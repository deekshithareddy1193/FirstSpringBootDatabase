package BackendDevelopers.FirstSpringBoot.dao;


import java.util.HashMap;

import org.springframework.stereotype.Repository;
import org.springframework.data.repository.CrudRepository;

import BackendDevelopers.FirstSpringBoot.Model.Product;
@Repository
public interface ProductsList extends CrudRepository<Product,Integer>{
	/*CrudRepository<Product,Integer>
	 * Product is the data that will inserted into the database
	 * or retrieved from the database.
	 * Integer is the datatype of the primary key
	 */
}
